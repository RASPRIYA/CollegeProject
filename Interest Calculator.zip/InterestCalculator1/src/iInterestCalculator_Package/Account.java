package iInterestCalculator_Package;

public abstract class Account {
	double interestRate;
	double amount;
	abstract double calculateInterest();
}