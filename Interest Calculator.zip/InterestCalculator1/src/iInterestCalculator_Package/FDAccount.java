package iInterestCalculator_Package;


public class FDAccount extends Account {
	double interestRate;
	double amount;
	int days;
	int age;
	public FDAccount(Double a,int day,int ag) {
		this.amount=a;
		this.days=day;
		this.age=ag;
	}
	@Override
	double calculateInterest() {
		if(amount<=10000000) {
			if(days>=7 && days<=14) {
				if(age<60)
					interestRate=(4.50/(double)100)*amount;
				else
					interestRate=(5.00/(double)100)*amount;
			}
			else if(days>=15 && days<=29) {
				if(age<60)
					interestRate=(4.75/(double)100)*amount;
				else
					interestRate=(5.25/(double)100)*amount;
			}
			else if(days>=30 && days<=45) {
				if(age<60)
					interestRate=(5.50/(double)100)*amount;
				else
					interestRate=(6.00/(double)100)*amount;
			}
			else if(days>=46 && days<=60) {
				if(age<60)
					interestRate=(7.00/(double)100)*amount;
				else
					interestRate=(7.50/(double)100)*amount;
			}
			else if(days>=61 && days<=184) {
				if(age<60)
					interestRate=(7.50/(double)100)*amount;
				else
					interestRate=(8.00/(double)100)*amount;
			}
			else if(days>=185 && days<=365) {
				if(age<60)
					interestRate=(8.00/(double)100)*amount;
				else
					interestRate=(8.50/(double)100)*amount;
			}
		}
		else {
			if(days>=7 && days<=14) {
				interestRate=(6.50/(double)100)*amount;
			}
			else if(days>=15 && days<=29) {
				interestRate=(6.75/(double)100)*amount;
			}
			else if(days>=15 && days<=29) {
				interestRate=(6.75/(double)100)*amount;
			}
			else if(days>=15 && days<=29) {
				interestRate=(8.00/(double)100)*amount;
			}
			else if(days>=15 && days<=29) {
				interestRate=(8.50/(double)100)*amount;
			}
			else if(days>=15 && days<=29) {
				interestRate=(10.00/(double)100)*amount;
			}
		}
		return interestRate;
	}

}
