package iInterestCalculator_Package;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.Iterator;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.*;
public class Bank {
	JFrame f,frameFD,frameSB,frameRD;
	public Bank() {
		f=new JFrame("Interest");
		JLabel l1=new JLabel("INTEREST CALCULATOR");
		l1.setBounds(150,10,200,40);
		
		//sort by buttons
		JLabel l2=new JLabel("Choose type of Account");
		l2.setBounds(40,60,150,40);		
		String type[]= {"FD Account","SB Account","RD Account"};
		JComboBox by=new JComboBox(type);
		by.setBounds(200,60,220,40);
		
		//output
		JLabel l3=new JLabel("Final Interest");
		l3.setBounds(40,130,100,40);
		JTextArea fin=new JTextArea();
		fin.setBounds(200,130,220,40);
		fin.setEditable(false);
		fin.setBackground(Color.orange);
		
		by.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String test=String.valueOf(by.getItemAt(by.getSelectedIndex()));
				fin.setText("");
				double resultFD,resultSB,resultRD;
				if(test=="FD Account") {
					frameFD=new JFrame();
					String amount=JOptionPane.showInputDialog(frameFD,"Enter the FD amount");
					String days=JOptionPane.showInputDialog(frameFD,"Enter the number of days");
					String age=JOptionPane.showInputDialog(frameFD,"Enter your age");
					FDAccount obj1=new FDAccount(Double.valueOf(amount),Integer.valueOf(days),Integer.valueOf(age));
					resultFD=obj1.calculateInterest();
					fin.setText(String.valueOf(resultFD));
				}
				else if(test=="SB Account") {
					frameSB=new JFrame();
					String amount=JOptionPane.showInputDialog(frameSB,"Enter your amount");
					String type=JOptionPane.showInputDialog(frameSB,"Enter the type of account(Normal/NRI)");
					SBAccount obj2=new SBAccount(Double.valueOf(amount),type);
					resultSB=obj2.calculateInterest();
					fin.setText(String.valueOf(resultSB));
					
				}
				else if(test=="RD Account") {
					frameRD=new JFrame();
					String amount=JOptionPane.showInputDialog(frameFD,"Enter the RD amount");
					String months=JOptionPane.showInputDialog(frameFD,"Enter the number of months");
					String age=JOptionPane.showInputDialog(frameFD,"Enter your age");
					FDAccount obj3=new FDAccount(Double.valueOf(amount),Integer.valueOf(months),Integer.valueOf(age));
					resultRD=obj3.calculateInterest();
					fin.setText(String.valueOf(resultRD));
				}
			}
		});
		
		//frame
		f.setSize(550,450);
		f.add(l1);f.add(by);f.add(fin);f.add(l2);f.add(l3);
		f.setLayout(null);
		f.setVisible(true);
	}

	public static void main(String[] args) {
		Bank obj=new Bank();
		}

}
