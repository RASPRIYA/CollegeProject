package iInterestCalculator_Package;


public class SBAccount extends Account{
	double interestRate;
	double amount;
	String type;
public SBAccount(double a,String ty){
		this.amount =a;
		this.type=ty;
	}
String str="NRI";
	@Override
	
	double calculateInterest() {
		if(type.equals(str)) 
			interestRate=((double)6/100)*amount;
		else
			interestRate=((double)4/100)*amount;	
		return interestRate;
	}

}
