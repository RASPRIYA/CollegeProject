package iInterestCalculator_Package;


public class RDAccount extends Account{
	double interestRate;
	double amount;
	int nom;
	int age;
	RDAccount(double a,int months,int ag){
		this.amount=a;
		this.nom=months;
		this.age=ag;
	}
	@Override
	double calculateInterest() {
		if(nom<=6) {
			if(age<60)
				interestRate=(7.50/(double)100)*amount;
			else
				interestRate=(8.00/(double)100)*amount;
		}
		else if(nom>6 && nom<=9) {
			if(age<60)
				interestRate=(7.75/(double)100)*amount;
			else
				interestRate=(8.25/(double)100)*amount;
		}
		else if(nom>9 && nom<=12) {
			if(age<60)
				interestRate=(8.00/(double)100)*amount;
			else
				interestRate=(8.50/(double)100)*amount;
		}
		else if(nom>12 && nom<=15) {
			if(age<60)
				interestRate=(8.25/(double)100)*amount;
			else
				interestRate=(8.75/(double)100)*amount;
		}
		else if(nom>15 && nom<=18) {
			if(age<60)
				interestRate=(8.50/(double)100)*amount;
			else
				interestRate=(9.00/(double)100)*amount;
		}
		else if(nom>18 && nom<=21) {
			if(age<60)
				interestRate=(8.75/(double)100)*amount;
			else
				interestRate=(9.25/(double)100)*amount;
		}
		return interestRate;
	}

}
